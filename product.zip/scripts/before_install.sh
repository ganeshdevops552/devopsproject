#!/bin/bash
echo "Before install script " >> /opt/beforeinstall.log
echo " New Before install script " >> /opt/beforeinstall.log